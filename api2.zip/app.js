const express = require('express')
const app = express()
const rotas = require('./routers')

const bodyParser = require('body-parser');
app.use(bodyParser.json());

app.get('/listar', rotas.listar)
app.get('/listar/:id', rotas.listarPorID)
app.post('/criar', rotas.criar);
app.put('/atualizar/:id', rotas.atualizar);
app.delete('/deletar/:id', rotas.deletar);


const port = 3000 

app.listen(port, () => {
  console.log(`App listening on: http://localhost:${port}`)
})

