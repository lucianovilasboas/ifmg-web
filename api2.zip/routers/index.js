const crud = require('../helper/tarefas');

exports.listar = (req, res) => {
    res.json(crud.listar())
}

exports.listarPorID = (req, res) => {
    const id = req.params.id
    res.json(crud.listarPorId(id))
}

exports.criar = (req, res) => {
    const body = req.body
    // res.json(crud.criar(body))
    crud.criar(body)
    return res.status(201).send()
}


exports.atualizar = (req, res) => {
    const body = req.body
    const id = req.params.id
    crud.atualizar(id, body)

    return res.status(204).send()
}

exports.deletar = (req, res) => {
    const id = req.params.id
    crud.deletar(id)
    return res.status(204).send()
}
